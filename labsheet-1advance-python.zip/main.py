# 1. Student marks vs passing marks
# marks = int(input("Enter student marks: "))
# pass_marks = 40

# if marks >= pass_marks:
#     print("Student has passed")
# else:
#     print("Student has failed")

# 2. Employee salary vs company minimum salary
# salary = int(input("Enter employee salary: "))
# min_salary = 15000

# print("Salary >= Minimum:", salary >= min_salary)
# print("Salary < Minimum:", salary < min_salary)

# 3. Age vs voting age
# age = int(input("Enter age: "))
# voting_age = 18

# if age == voting_age:
#     print("Age is equal to voting age")
# elif age > voting_age:
#     print("Eligible to vote")
# else:
#     print("Not eligible to vote")

# 4. Compare price of two products
# p1 = int(input("Enter price of product 1: "))
# p2 = int(input("Enter price of product 2: "))

# if p1 > p2:
#     print("Product 1 is costlier")
# elif p2 > p1:
#     print("Product 2 is costlier")
# else:
#     print("Both products have same price")

# 5. Account balance vs withdrawal amount
# balance = int(input("Enter account balance: "))
# withdraw = int(input("Enter withdrawal amount: "))

# if balance >= withdraw:
#     print("Withdrawal successful")
# else:
#     print("Insufficient balance")

# 6. Attendance eligibility
# attendance = float(input("Enter attendance percentage: "))
# required = 75

# if attendance >= required:
#     print("Eligible for exam")
# else:
#     print("Not eligible for exam")

# # 7. Temperature comparison
# temp = float(input("Enter current temperature: "))

# if 20 <= temp <= 30:
#     print("Temperature is normal")
# else:
#     print("Temperature is not normal")

# 8. Employee working hours
# hours = int(input("Enter working hours: "))
# required = 8

# if hours == required:
#     print("Working hours are exact")
# elif hours > required:
#     print("Working hours are more")
# else:
#     print("Working hours are less")

# 9. Income vs tax exemption limit
# income = int(input("Enter monthly income: "))
# limit = 25000

# if income > limit:
#     print("Tax applicable")
# else:
#     print("No tax")

# 10. Compare delivery times
 

# 11. Positive and even number (AND + while)
# choice = "YES"
# while choice.upper() == "YES":
#     num = int(input("Enter a number: "))
#     if num > 0 and num % 2 == 0:
#         print("Number is positive and even")
#     else:
#         print("Condition not satisfied")
#     choice = input("Enter YES to continue or NO to stop: ")

# 12. Five subjects pass check (AND + for + break)
# for i in range(1, 6):
#     marks = int(input(f"Enter marks of subject {i}: "))
#     if marks < 40:
#         print("Student failed")
#         break
# else:
#     print("Student passed all subjects")

# 13. Voting eligibility menu (AND)
# while True:
#     print("1. Check Eligibility")
#     print("2. Exit")
#     ch = int(input("Enter choice: "))

#     if ch == 1:
#         age = int(input("Enter age: "))
#         citizen = input("Citizen (YES/NO): ").upper()
#         if age >= 18 and citizen == "YES":
#             print("Eligible to vote")
#         else:
#             print("Not eligible")
#     else:
#         break

# 14. Bonus eligibility (AND + ternary)
# salary = int(input("Enter salary: "))
# exp = int(input("Enter experience: "))

# result = "Eligible for bonus" if salary >= 30000 and exp >= 5 else "Not eligible"
# print(result)

# 15. Leap year check (AND + OR)
# year = int(input("Enter year: "))

# if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
#     print("Leap year")
# else:
#     print("Not a leap year")

# 16. Divisible by 3 or 5 (OR + while)
# while True:
#     num = int(input("Enter number: "))
#     if num % 3 == 0 or num % 5 == 0:
#         print("Divisible by 3 or 5")
#     else:
#         print("Not divisible")
#     if input("Continue? (YES/NO): ").upper() == "NO":
#         break

# 17. Sports quota eligibility (OR)
# state = input("State level player (YES/NO): ").upper()
# national = input("National level player (YES/NO): ").upper()

# if state == "YES" or national == "YES":
#     print("Eligible for sports quota")
# else:
#     print("Not eligible")

# 18. Discount eligibility menu (OR)
# while True:
#     print("1. Check Discount")
#     print("2. Exit")
#     ch = int(input("Enter choice: "))

#     if ch == 1:
#         amount = int(input("Enter purchase amount: "))
#         member = input("Member (YES/NO): ").upper()
#         if amount >= 5000 or member == "YES":
#             print("Discount applicable")
#         else:
#             print("No discount")
#     else:
#         break

# 19. Job eligibility (OR + ternary)
# degree = input("Degree (YES/NO): ").upper()
# exp = int(input("Experience: "))

# result = "Eligible" if degree == "YES" or exp >= 3 else "Not Eligible"
# print(result)

# 20. Weekend check (OR)
# day = input("Enter day: ").lower()

# if day == "saturday" or day == "sunday":
#     print("Weekend")
# else:
#     print("Weekday")

# 21. Blood donation (NOT)
# age = int(input("Enter age: "))

# if not (18 <= age <= 60):
#     print("Not eligible to donate blood")
# else:
#     print("Eligible to donate blood")

# 22. Reverse login status (NOT)
# login = input("Logged in (YES/NO): ").upper()

# print("Reversed login:", not (login == "YES"))

# 23. Number not positive (NOT)
# num = int(input("Enter number: "))

# if not (num > 0):
#     print("Number is not positive")
# else:
#     print("Number is positive")

# 24. User not admin (NOT)
# role = input("Enter role: ").lower()

# if not (role == "admin"):
#     print("User is not admin")
# else:
#     print("User is admin")

# 25. Student not absent (NOT)
# status = input("Attendance (PRESENT/ABSENT): ").upper()

# if not (status == "ABSENT"):
#     print("Student is not absent")
# else:
#     print("Student is absent")

# 26. Loan eligibility (AND + NOT)
# income = int(input("Income: "))
# credit = int(input("Credit score: "))
# defaulter = input("Defaulter (YES/NO): ").upper()

# if income >= 30000 and credit >= 700 and not (defaulter == "YES"):
#     print("Loan approved")
# else:
#     print("Loan rejected")

# 27. System access (AND + NOT)
# login = input("Logged in (YES/NO): ").upper()
# blocked = input("Blocked (YES/NO): ").upper()

# if login == "YES" and not (blocked == "YES"):
#     print("Access granted")
# else:
#     print("Access denied")

# 28. Student promotion (AND + OR + NOT)
# result = input("Pass exam (YES/NO): ").upper()
# sports = input("Sports quota (YES/NO): ").upper()
# detained = input("Detained (YES/NO): ").upper()

# if (result == "YES" or sports == "YES") and not (detained == "YES"):
#     print("Student promoted")
# else:
#     print("Not promoted")

# 29. Vehicle entry check (AND + OR)
# permit = input("Permit (YES/NO): ").upper()
# emission = input("Emission test (YES/NO): ").upper()
# emergency = input("Emergency vehicle (YES/NO): ").upper()

# if (permit == "YES" and emission == "YES") or emergency == "YES":
#     print("Vehicle allowed")
# else:
#     print("Vehicle not allowed")

# 30. Work-from-home eligibility (AND + OR + NOT + while)
# choice = "YES"
# while choice.upper() == "YES":
#     senior = input("Senior employee (YES/NO): ").upper()
#     medical = input("Medical reason (YES/NO): ").upper()
#     notice = input("Serving notice period (YES/NO): ").upper()

#     if (senior == "YES" or medical == "YES") and not (notice == "YES"):
#         print("WFH allowed")
#     else:
#         print("WFH not allowed")

#     choice = input("Continue? (YES/NO): ")